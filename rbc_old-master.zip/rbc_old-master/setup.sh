sudo apt update
sudo apt install golang-go
sudo apt install ffmpeg
sudo apt install -y python3 python3-pip

echo "Package installing..."
echo -n "HTTProuter " & go get github.com/julienschmidt/httprouter && echo "success!" || echo "FAIL!"
echo -n "Pudge " & go get github.com/recoilme/pudge && echo "success!" || echo "FAIL!"
echo -n "Colorizer " & go github.com/JennieSex/colorizer && echo "success!" || echo "FAIL!"
echo -n "Mutagen " & python3.10 -m pip install mutagen && echo "success!" || echo "FAIL!"
echo -n "Telethon " & python3.10 -m pip install telethon && echo "success!" || echo "FAIL!"
echo -n "Requests " & python3.10 -m pip install requests && echo "success!" || echo "FAIL!"
echo -n "AIOhttp " & python3.10 -m pip install aiohttp && echo "success!" || echo "FAIL!"
echo -n "Ping3" & python3.10 -m pip install ping3 && echo "success!" || echo "FAIL!"
echo -n "Orjson" & python3.10 -m pip install orjson && echo "success!" || echo "FAIL!"
echo -n "Vk_captchasolver" & python3.10 -m pip install vk_captchasolver && echo "success!" || echo "FAIL!"
echo -n "Loguru" & python3.10 -m pip install loguru && echo "success!" || echo "FAIL!"
echo -n "Pillow" & python3.10 -m pip install pillow==9.0.0 && echo "success!" || echo "FAIL!"
echo -n "Uptime" & python3.10 -m pip install uptime && echo "success!" || echo "FAIL!"
echo -n "Psutil" & python3.10 -m pip install psutil && echo "success!" || echo "FAIL!"
echo -n "Dpath" & python3.10 -m pip install dpath && echo "success!" || echo "FAIL!"
echo -n "Demapi" & python3.10 -m pip install demapi && echo "success!" || echo "FAIL!"
echo -n "Gtts" & python3.10 -m pip install gtts && echo "success!" || echo "FAIL!"
echo -n "Gtts" & python3.10 -m pip install gtts && echo "success!" || echo "FAIL!"
echo -n "Wikipedia" & python3.10 -m pip install wikipedia && echo "success!" || echo "FAIL!"
echo -n "Aiogram" & python3.10 -m pip install aiogram && echo "success!" || echo "FAIL!"

chmod +x compile.sh

echo "Compiling binaries..."
./compile.sh

chmod +x start.sh
echo "Done!"