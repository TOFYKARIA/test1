Необходимые либы для питона - aiohttp, requests, mutagen, telethon
По умолчанию команда для запуска интерпретатора - python3.8

Можно запускать ecosystem.json через pm2, это наилучший вариант